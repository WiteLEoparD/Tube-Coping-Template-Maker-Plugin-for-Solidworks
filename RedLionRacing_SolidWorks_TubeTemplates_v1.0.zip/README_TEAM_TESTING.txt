===============================================================================
 RED LION RACING — UNIVERSITY OF MANITOBA
 SolidWorks 1:1 Tube Cut Template Generator & Chassis Locator Diagram Add-in
 Team Member Quick-Start Testing Guide
===============================================================================

HOW TO INSTALL (Takes 10 Seconds):
----------------------------------
1. Make sure SolidWorks is closed.
2. Double-click "RedLionRacing_TubeTemplates_Installer.exe".
3. Click the red "Install / Update Add-in" button.
4. When the log displays "SUCCESS: Ready for testing!", you are done!
   (No administrator rights required — works on any student/lab laptop).

HOW TO TEST IN SOLIDWORKS:
--------------------------
1. Launch SolidWorks (2022, 2023, 2024, 2025, or 2026).
2. Open any chassis weldment (.sldprt) or frame assembly (.sldasm).
3. Look at your CommandManager ribbon tabs:
   - You will see a dedicated "Tube Templates" tab next to Features and Weldments.
   - Click the "Tube Cut Templates" button (or go to Tools > Red Lion Racing Tube Templates).
4. The PropertyManagerPage will open:
   - Check "Select All Chassis Tubes" (auto-scans 0.75" to 1.75" tubing), or click individual tubes in the graphics area.
   - Verify Collar Length is set to 1.50".
   - Select your export formats (PDF 1:1, DXF, SVG).
   - Click "Generate Cut Templates Now".
5. In your chosen folder, you will find:
   - 1:1 scale US Letter printable PDF with Red Lion Racing branding and Calibration Box.
   - AutoCAD DXF for plasma/laser notchers.
   - Physical unit SVG.

VERIFYING PRINT SCALE:
----------------------
1. Open the generated PDF in Adobe Acrobat or browser.
2. Print to physical paper with page scaling set to "Actual Size (100%)" (NEVER "Fit to Page").
3. Use digital calipers to measure the 1.000" x 1.000" square calibration box in the corner.
   - If it measures exactly 1.000" x 1.000", your cut wrap is 100% physically accurate!
4. Wrap the template around raw tubing, aligning the red CL [0 deg] line to your scribed seam line.

HOW TO UNINSTALL:
-----------------
Double-click "RedLionRacing_TubeTemplates_Installer.exe" and click "Uninstall", or run "Uninstall.bat".
