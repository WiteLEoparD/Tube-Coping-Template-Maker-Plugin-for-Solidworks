@echo off
setlocal enabledelayedexpansion
title Red Lion Racing - SolidWorks Add-in Installer

echo ============================================================================
echo   RED LION RACING -- UNIVERSITY OF MANITOBA
echo   1:1 Chassis Tube Cut Templates SolidWorks Add-in Setup
echo ============================================================================
echo.

:: 1. Launch GUI Installer if available
if exist "%~dp0RedLionRacing_TubeTemplates_Installer.exe" (
    echo Launching Graphical Setup...
    start "" "%~dp0RedLionRacing_TubeTemplates_Installer.exe"
    exit /b 0
)

:: 2. Fallback headless install
set "TARGET_DIR=%LOCALAPPDATA%\RedLionRacing\SolidWorks_TubeTemplates"
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

echo Copying assemblies to: %TARGET_DIR%
copy /y "%~dp0Payload\*.dll" "%TARGET_DIR%\" >nul

echo Registering Add-in with SolidWorks...
powershell -NoProfile -ExecutionPolicy Bypass -Command "& { $guid = '{769C5C1D-E143-4D90-A951-BEB1309CD51E}'; $dll = '%TARGET_DIR%\BajaSAE.TubeCutTemplateAddin.dll'; New-Item -Path \"HKCU:\Software\Classes\CLSID\$guid\InprocServer32\" -Force | Out-Null; Set-ItemProperty -Path \"HKCU:\Software\Classes\CLSID\$guid\" -Name '(Default)' -Value 'BajaSAE.TubeCutTemplateAddin.SwAddin'; Set-ItemProperty -Path \"HKCU:\Software\Classes\CLSID\$guid\InprocServer32\" -Name '(Default)' -Value 'mscoree.dll'; Set-ItemProperty -Path \"HKCU:\Software\Classes\CLSID\$guid\InprocServer32\" -Name 'ThreadingModel' -Value 'Both'; Set-ItemProperty -Path \"HKCU:\Software\Classes\CLSID\$guid\InprocServer32\" -Name 'Class' -Value 'BajaSAE.TubeCutTemplateAddin.SwAddin'; Set-ItemProperty -Path \"HKCU:\Software\Classes\CLSID\$guid\InprocServer32\" -Name 'Assembly' -Value 'BajaSAE.TubeCutTemplateAddin, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null'; Set-ItemProperty -Path \"HKCU:\Software\Classes\CLSID\$guid\InprocServer32\" -Name 'RuntimeVersion' -Value 'v4.0.30319'; Set-ItemProperty -Path \"HKCU:\Software\Classes\CLSID\$guid\InprocServer32\" -Name 'CodeBase' -Value ([System.Uri]::new($dll).AbsoluteUri); New-Item -Path \"HKCU:\Software\SolidWorks\Addins\$guid\" -Force | Out-Null; Set-ItemProperty -Path \"HKCU:\Software\SolidWorks\Addins\$guid\" -Name '(Default)' -Value 1 -Type DWord; Set-ItemProperty -Path \"HKCU:\Software\SolidWorks\Addins\$guid\" -Name 'Title' -Value 'Red Lion Racing Tube Templates'; Set-ItemProperty -Path \"HKCU:\Software\SolidWorks\Addins\$guid\" -Name 'Description' -Value 'Auto-generates 1:1 scale printable cut templates for Red Lion Racing (University of Manitoba).'; Write-Host '[SUCCESS] Add-in registered for Current User!' -ForegroundColor Green }"

echo.
echo ============================================================================
echo   SUCCESS! The Add-in is now installed.
echo   Launch SolidWorks and look for 'Tube Templates' in the CommandManager.
echo ============================================================================
pause
