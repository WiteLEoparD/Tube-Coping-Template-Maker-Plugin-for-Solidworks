@echo off
title Red Lion Racing - Uninstall SolidWorks Add-in
echo ============================================================================
echo   Uninstalling Red Lion Racing Tube Cut Templates Add-in...
echo ============================================================================

powershell -NoProfile -ExecutionPolicy Bypass -Command "& { $guid = '{769C5C1D-E143-4D90-A951-BEB1309CD51E}'; Remove-Item -Path \"HKCU:\Software\SolidWorks\Addins\$guid\" -Recurse -ErrorAction SilentlyContinue; Remove-Item -Path \"HKCU:\Software\Classes\CLSID\$guid\" -Recurse -ErrorAction SilentlyContinue; Write-Host '[SUCCESS] Removed registry entries.' -ForegroundColor Green }"

set "TARGET_DIR=%LOCALAPPDATA%\RedLionRacing\SolidWorks_TubeTemplates"
if exist "%TARGET_DIR%" (
    rmdir /s /q "%TARGET_DIR%" 2>nul
    echo Removed files from %TARGET_DIR%
)

echo.
echo Uninstallation Complete!
pause
